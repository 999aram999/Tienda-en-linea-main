<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\saleDetails;
use Faker\Generator as Faker;

$factory->define(saleDetails::class, function (Faker $faker) {
    return [
        //
    ];
});
