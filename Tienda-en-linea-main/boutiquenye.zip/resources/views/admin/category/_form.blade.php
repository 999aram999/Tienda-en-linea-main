<div class="form-group">
  <label for="name">Nombre</label>
  <input type="text" name="name" id="name" class="form-control" placeholder="Nombre" required>
</div>
