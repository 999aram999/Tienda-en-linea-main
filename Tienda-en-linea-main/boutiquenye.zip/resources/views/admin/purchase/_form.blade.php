{{--  <div class="form-row">
    <div class="form-group col-md-6">
      
    </div>
    <div class="form-group col-md-4">
       
    </div>
    <div class="form-group col-md-2">
        
    </div>
</div>  --}}
        <div class="form-group">
            <label for="descripcion">Descripción</label>
            <input type="text" class="form-control" name="descripcion" id="descripcion" aria-describedby="helpId" required>
        </div>
        <div class="form-group">
            <label for="monto">Total</label>
            <input type="number" class="form-control" name="monto" id="monto" aria-describedby="helpId">
        </div>
       