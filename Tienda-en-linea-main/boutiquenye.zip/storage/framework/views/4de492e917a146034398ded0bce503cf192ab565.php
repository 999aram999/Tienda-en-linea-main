
<?php $__env->startSection('title','Registro de pago'); ?>
<?php $__env->startSection('styles'); ?>
<?php echo Html::style('select/dist/css/bootstrap-select.min.css'); ?>

<style type="text/css">
    .unstyled-button {
        border: none;
        padding: 0;
        background: none;
    }

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('create'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('options'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('preference'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="page-header">
        <h3 class="page-title">
            Registro de pago
        </h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Panel administrador</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('payments.index')); ?>">Pagos</a></li>
                <li class="breadcrumb-item active" aria-current="page">Registro de pago</li>
            </ol>
        </nav>
    </div>
    <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="form-group row">
                        <div class="col-md-4 text-center">
                            <label class="form-control-label"><strong>Cliente</strong></label>
                            <p><a href="<?php echo e(route('clients.show', $venta->client)); ?>"><?php echo e($sale->client->name); ?></a></p>
                        </div>
                        <div class="col-md-4 text-center">
                            <label class="form-control-label"><strong>Vendedor</strong></label>
                            <p>
                                <a href="<?php echo e(route('users.show',$venta->user)); ?>"><?php echo e($sale->user->name); ?></a>
                            </p>
                        </div>
                        <div class="col-md-4 text-center">
                            <label class="form-control-label"><strong>Número Venta</strong></label>
                            <p><?php echo e($sale->id); ?></p>
                        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    
                    <div class="d-flex justify-content-between">
                        <h4 class="card-title">Registro de Pago</h4>
                    </div>
                    <div class="form-group">
                        <label for="saldo">Saldo Pendiente</label>
                        <input type="number" name="saldo" id="saldo" class="form-control" aria-describedby="helpId" value="<?php echo e($sale->saldo); ?>" required>
                    </div>
                    <?php echo Form::open(['route'=>'payments.store', 'method'=>'POST','files' => true]); ?>

                   

                    <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group">
                        <label for="sale_id">No. de cuenta</label>
                        <input type="number" name="sale_id" id="sale_id" class="form-control" aria-describedby="helpId" value="<?php echo e($sale->id); ?>" required>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group">
                        <label for="quantity">Cantidad de pago</label>
                        <input type="number" name="quantity" id="quantity" class="form-control" aria-describedby="helpId" required>
                    </div>

                     <button type="submit" class="btn btn-primary mr-2">Registrar</button>
                     <a href="<?php echo e(route('payments.index')); ?>" class="btn btn-light">
                        Cancelar
                     </a>
                     <?php echo Form::close(); ?>

                </div>
                
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo Html::script('melody/js/alerts.js'); ?>

<?php echo Html::script('melody/js/avgrund.js'); ?>

<?php echo Html::script('select/dist/js/bootstrap-select.min.js'); ?>

<?php echo Html::script('js/sweetalert2.all.min.js'); ?>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\boutiquenye\resources\views/admin/payment/create.blade.php ENDPATH**/ ?>