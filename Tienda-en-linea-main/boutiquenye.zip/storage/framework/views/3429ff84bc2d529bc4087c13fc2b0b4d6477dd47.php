<?php $__env->startSection('title','Detalles de venta'); ?>
<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('create'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('options'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('preference'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="page-header">
        <h3 class="page-title">
            Detalles de venta
        </h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Panel administrador</a></li>
                <li class="breadcrumb-item"><a href="#">Ventas</a></li>
                <li class="breadcrumb-item active" aria-current="page">Detalles de venta</li>
            </ol>
        </nav>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="form-group row">
                        <div class="col-md-3 text-center">
                            <label class="form-control-label"><strong>Cliente</strong></label>
                            <p><a href="<?php echo e(route('clients.show', $sale->client)); ?>"><?php echo e($sale->client->name); ?></a></p>
                        </div>
                        <div class="col-md-3 text-center">
                            <label class="form-control-label"><strong>Vendedor</strong></label>
                            <p>
                                <a href="<?php echo e(route('users.show',$sale->user)); ?>"><?php echo e($sale->user->name); ?></a>
                            </p>
                        </div>
                        <div class="col-md-3 text-center">
                            <label class="form-control-label"><strong>Número Venta</strong></label>
                            <p><?php echo e($sale->id); ?></p>
                        </div>
                        <div class="col-md-3 text-center">
                            <label class="form-control-label"><strong>Saldo pendiente</strong></label>
                            <p><?php echo e($sale->saldo); ?></p>
                        </div>
                    </div>
                    <br /><br />
                    <div class="form-group">
                        <h4 class="card-title">Detalles de venta</h4>
                        <div class="table-responsive col-md-12">
                            <table id="saleDetails" class="table">
                                <thead>
                                    <tr>
                                        <th>Producto</th>
                                        <th>Precio Venta (PEN)</th>
                                        <th>Descuento(PEN)</th>
                                        <th>Cantidad</th>
                                        <th>SubTotal(PEN)</th>
                                    </tr>
                                </thead>
                                <tfoot>

                                    <tr>
                                        <th colspan="4">
                                            <p align="right">SUBTOTAL:</p>
                                        </th>
                                        <th>
                                            <p align="right">s/<?php echo e(number_format($subtotal,2)); ?></p>
                                        </th>
                                    </tr>

                                    <tr>
                                        <th colspan="4">
                                            <p align="right">TOTAL IMPUESTO (<?php echo e($sale->tax); ?>%):</p>
                                        </th>
                                        <th>
                                            <p align="right">s/<?php echo e(number_format($subtotal*$sale->tax/100,2)); ?></p>
                                        </th>
                                    </tr>
                                    <tr>
                                        <th colspan="4">
                                            <p align="right">TOTAL:</p>
                                        </th>
                                        <th>
                                            <p align="right">s/<?php echo e(number_format($sale->total,2)); ?></p>
                                        </th>
                                    </tr>

                                </tfoot>
                                <tbody>
                                    <?php $__currentLoopData = $saleDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saleDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($saleDetail->product->name); ?></td>
                                        <td>s/<?php echo e($saleDetail->price); ?></td>
                                        <td><?php echo e($saleDetail->discount); ?> %</td>
                                        <td><?php echo e($saleDetail->quantity); ?></td>
                                        <td>s/<?php echo e(number_format($saleDetail->quantity*$saleDetail->price - $saleDetail->quantity*$saleDetail->price*$saleDetail->discount/100,2)); ?>

                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                   
                    <div class="form-group">
                        <h4 class="card-title">Pagos realizados</h4>
                        <div class="table-responsive col-md-12">
                            <table id="saleDetails" class="table">
                                <thead>
                                    <tr>
                                        <th>No.Pago</th>
                                        <th>Fecha</th>
                                        <th>Cantidad</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($venta->id); ?></td>
                                        <td>s/<?php echo e($venta->payment_date); ?></td>
                                        <td><?php echo e($venta->quantity); ?> </td>
                                        
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="card-footer text-muted">
                    <a href="<?php echo e(route('sales.index')); ?>" class="btn btn-primary float-right">Regresar</a>
                </div>
               
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo Html::script('melody/js/profile-demo.js'); ?>

<?php echo Html::script('melody/js/data-table.js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\boutiquenye\resources\views/admin/sale/show.blade.php ENDPATH**/ ?>