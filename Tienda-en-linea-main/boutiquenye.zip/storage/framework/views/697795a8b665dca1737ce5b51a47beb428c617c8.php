

  <div class="form-row">
    <div class="form-group col-md-6">
        <div class="form-group">
            <label for="sale_id">Saldo</label>
            <input type="number" class="form-control" name="sale_id" id="sale_id"  aria-describedby="helpId" >
          </div>
    </div>

    <div class="form-group col-md-6">
        <div class="form-group">
            <label for="quantity">Abono</label>
            <input type="number" class="form-control" name="quantity" id="quantity"  aria-describedby="helpId">
        </div>
    </div>
  </div>


<?php /**PATH D:\laragon\www\boutiquenye\resources\views/admin/payment/_form.blade.php ENDPATH**/ ?>