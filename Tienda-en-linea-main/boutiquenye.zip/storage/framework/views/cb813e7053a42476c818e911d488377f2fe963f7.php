<!DOCTYPE html>
<html lang="en">



<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>N & E BOUTIQUE</title>
  <!-- plugins:css -->
  <?php echo Html::style('melody/vendors/iconfonts/font-awesome/css/all.min.css'); ?>

  <?php echo Html::style('melody/vendors/css/vendor.bundle.base.css'); ?>

  <?php echo Html::style('melody/vendors/css/vendor.bundle.addons.css'); ?>

  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <?php echo Html::style('melody/css/style.css'); ?>

  <!-- endinject -->
  <link rel="shortcut icon" href="melody/images/favicon.png" />
</head>

<body>
  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper">
      <div class="content-wrapper d-flex align-items-stretch auth auth-img-bg">
        <div class="row flex-grow">
          <div class="col-lg-12 d-flex align-items-center justify-content-center">
            <div class="auth-form-transparent text-left p-3">
              <div class="brand-logo">
                <center><img src="<?php echo e(asset('melody/images/logos.jpg')); ?>" alt="logo">
              </div>
              
              <?php echo $__env->yieldContent('content'); ?>


            </div>
          </div>
          
            <p class="text-white font-weight-medium text-center flex-grow align-self-end">Copyright &copy; 2020 Todos los derechos reservados</p>
          </div>
        </div>
      </div>
      <!-- content-wrapper ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <?php echo Html::script('melody/vendors/js/vendor.bundle.base.js'); ?>

  <?php echo Html::script('melody/vendors/js/vendor.bundle.addons.js'); ?>

  <!-- endinject -->
  <!-- inject:js -->
  <?php echo Html::script('melody/js/off-canvas.js'); ?>

  <?php echo Html::script('melody/js/hoverable-collapse.js'); ?>

  <?php echo Html::script('melody/js/misc.js'); ?>

  <?php echo Html::script('melody/js/settings.js'); ?>

  <?php echo Html::script('melody/js/todolist.js'); ?>

  <!-- endinject -->
</body>
</html>
<?php /**PATH D:\laragon\www\boutiquenye\resources\views/layouts/login.blade.php ENDPATH**/ ?>