
        <div class="form-group">
            <label for="descripcion">Descripción</label>
            <input type="text" class="form-control" name="descripcion" id="descripcion" aria-describedby="helpId" required>
        </div>
        <div class="form-group">
            <label for="monto">Total</label>
            <input type="number" class="form-control" name="monto" id="monto" aria-describedby="helpId">
        </div>
       <?php /**PATH D:\laragon\www\boutiquenye\resources\views/admin/purchase/_form.blade.php ENDPATH**/ ?>